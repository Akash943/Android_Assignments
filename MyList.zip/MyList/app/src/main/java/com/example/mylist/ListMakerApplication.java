package com.example.mylist;

import android.app.Application;

public class ListMakerApplication extends Application {
}
